
/**
 * Write a description of class VariablePactrice here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class VariablePactrice
{
    // instance variables - replace the example below with your own
    public  int favouriteNumber()
    {
        int number = 7;
        return number;
    }
     
    public int numberofPets()
     {   int number = 5;
        return number;
    }
    
    public  double distanceToCollege()
    {
        double number = 12.5;
        return number;
    }
    
    public double temperatureToday()
    {
        double number = 18.5;
        return number;
    }
    
    public int pagesInBook(){
         int number =45;
         return number;
     } 
      
    public boolean likesProgramming(){ 
         boolean isLikes = true;
         return isLikes;  
    }
    
    public char firstInitial(){
        char initial = 'S';
        return initial;
    }
    
    public String favouriteColor(){
        String color= "Blue";
        return color;
    }
    
    public int countSteps(){
        int steps = 1000;
        steps = steps + 250;
        return steps;
    }
    
   
    
    public static int saveMoney() {
        int savings = 20; 
        savings += 15;    
        return savings;  
    }

    public static void main(String[] args) {
        
        int totalSavings = saveMoney();
        System.out.println("First total: " + totalSavings); 
    }
    
    public int doubleNumber(int number){
        int answer = number * 2;
        return answer; 
    }
    
    public int wholeNumberDivision(){
        int result = 7 / 2;
        return result;
    }
    
    public double decimalDivision(){
        double result = 7.0 / 2;
        return result;
    }
    
    public double surprisingDivision(){
    double result = 7 / 2;
    return result;
   }
    
   
   public class MethodPractice {

    // 1. Returns the number multiplied by itself
    public static int square(int number) {
        return number * number;
    }

    // 2. Calculates and returns the total price
    public static double totalPrice(double price, int quantity) {
        return price * quantity;
    }

    // 3. Returns the average of two numbers
    // Prediction for 5 and 8: (5 + 8) / 2.0 = 13 / 2.0 = 6.5
    public static double averageOfTwo(double first, double second) {
        return (first + second) / 2.0;
    }

    // 4. Declares a boolean variable, sets it, and returns it
    public static boolean isWeekend() {
        boolean weekend = true;
        return weekend;
    }

    // 5. Returns a personalized greeting string
    public static String greeting(String name) {
        return "Hello, " + name;
    }

    public static void main(String[] args) {
        
        System.out.println("square(4) = " + square(4));
        System.out.println("square(0) = " + square(0));
        System.out.println("square(-3) = " + square(-3));

        
        System.out.println("totalPrice(2.50, 3) = " + totalPrice(2.50, 3));

        
        System.out.println("averageOfTwo(5, 8) = " + averageOfTwo(5, 8));

        
        System.out.println("isWeekend() = " + isWeekend());

        
        System.out.println(greeting("Alex"));
        System.out.println(greeting("Jordan"));
    }
}
}
